# Fonts Directory

This directory contains Pretendard font files for the ChackChack app.

## Font Weights Used:
- Pretendard-Regular (400) - 보조 설명 텍스트
- Pretendard-Medium (500) - 버튼 텍스트, 필드 제목, 목록 아이템
- Pretendard-Bold (700) - 화면 제목

Note: For this demo, we'll use system fonts with appropriate weights as Pretendard files are not included in this codebase.